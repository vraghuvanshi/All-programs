package com.capgemini.beans;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the returneditems database table.
 * 
 */
@Entity
@Table(name="returneditems")
public class Returneditem implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="returniteam_id")
	private long Id;
	
	@OneToOne
	private Order order;
	
	@OneToOne
	private Customer customer;
	
	
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public Order getOrder() {
		return order;
	}
	
	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	private String returnStatus;


	public Returneditem() {
	}
	
	


	


	@Column(name="return_status", length=255)
	public String getReturnStatus() {
		return this.returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}


	
}