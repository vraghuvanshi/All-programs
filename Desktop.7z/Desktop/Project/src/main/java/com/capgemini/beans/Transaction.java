package com.capgemini.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the transactions database table.
 * 
 */
@Entity
@Table(name = "transactions")
public class Transaction implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "transaction_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private Date transactionDate;

	@OneToOne
	private Order order;

	@OneToMany
	//@JoinColumn(name = "product_id")
	private List<Product> product;

	public Transaction() {
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "transaction_date")
	public Date getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "order_id")
	public Order getOrder() {
		return this.order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public List<Product> getProduct() {
		return this.product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

}