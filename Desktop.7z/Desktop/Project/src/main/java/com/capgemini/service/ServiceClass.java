package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.beans.Product;
import com.capgemini.beans.Returneditem;
import com.capgemini.beans.Transaction;
import com.cg.repository.IDaoCategory;
import com.cg.repository.IDaoMerchant;
import com.cg.repository.IDaoOrder;
import com.cg.repository.IDaoProduct;
import com.cg.repository.IDaoReturneditem;

public class ServiceClass {
	
	public IDaoCategory idaocategory;
	
	
	
	@Autowired
	public IDaoMerchant idaomerchant;
	
	@Autowired
	public IDaoOrder idaoorder;
	@Autowired
	public IDaoProduct idaoproduct;
	
	@Autowired
	public IDaoReturneditem idaoreturneditem;




	
	
	
	

	

	@Transactional
	public void setReturnedItems(String prodid) {
		

		Returneditem rti = new Returneditem();
		rti.setCustomer(customer);
		
		idaoreturneditem.saveAndFlush(rti);
	}
	@Transactional
	public void setReturnStatus(String prodid) {

		String[] s = prodid.split(",");

		Returnstatus o =idaoreturnstatus.findById(Long.parseLong(s[8]));

		List<Returnstatus> oList = idaoreturnstatus.findAll();
		for (Returnstatus ot : oList) {
			if (ot.getReturnStatus() == o.getReturnStatus()) {
				ot.setReturnStatus("Pending");
				idaoreturnstatus.save(ot);
				break;
			}
		}
	}
	





	@Transactional
	public void deleteProduct(String id,int quan){
		Product p=idaoproduct.findOne(id);
		long amt=p.getProductStock()-quan;
		p.setProductStock(amt);
		idaoproduct.save(p);
	}


	@Transactional
	public void increaseProduct(String id, int quan) {
		Product p=idaoproduct.findOne(id);
		long amt=p.getProductStock()+quan;
		p.setProductStock(amt);
		idaoproduct.save(p);
	}
	public void setReturnApprove(long returnstatusId,String productId,long transactionId,double productCost) {

		
		
		idaoproduct.updateInventory(productId);
		
		BankWebServiceService b=new BankWebServiceService();

		BankWebService bs=b.getBankWebServicePort();

		bs.refund(transactionId,(float) productCost, "Product Refund");


		idaoreturneditem.setReturnedApprove(returnstatusId);

		idaoreturnstatus.setRStatusApprove(returnstatusId);
		

	}

	@Transactional
	public void setReturnReject(long returnstatusId) {

		i
	}












	@Transactional
	public List<Returneditem> storeDetails() {

		List<Returneditem> ret_list = idaoreturneditem.findAll();

		return ret_list;

	}




@Transactional
	public List<Transaction> getOrder(String id){
		List<Transaction> list=idaoorder.getBymerchantId(id);
		return list;
	}
}
