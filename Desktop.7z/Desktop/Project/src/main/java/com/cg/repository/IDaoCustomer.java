package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.beans.Customer;



@Repository
public interface IDaoCustomer extends JpaRepository<Customer,String>{
	@Transactional
	@Query("select u.CustomerPassword from Customer u where u.CustomerEmail=?1")
	public String getCustomerPassword(String email);
	
	@Transactional
	@Query("select u.CustomerStatus from Customer u where u.CustomerEmail=?1")
	public String getCustomerStatus(String email);
	
	@Transactional
	@Query("select u.CustomerId from Customer u where u.CustomerEmail=?1")
	public String getCustomerId(String email);
	
	@Transactional
	@Query("select u from Customer u where u.CustomerEmail=?1")
	public Customer findById(String email_id);
	
	@Transactional
	@Query("select u.CustomerFirstname from Customer u where u.CustomerEmail=?1")
	public String getCustomerName(String email);
	

	public Customer saveAndFlush(Customer customer);
}
