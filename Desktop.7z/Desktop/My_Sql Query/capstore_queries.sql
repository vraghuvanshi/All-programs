Hibernate: 
    create table address (
        address_id integer not null auto_increment,
        address_line varchar(255),
        city varchar(255),
        country varchar(255),
        create_date date,
        delete_date date,
        state varchar(255),
        zipcode varchar(255),
        primary key (address_id)
    )
Hibernate: 
    create table admin (
        admin integer not null auto_increment,
        create_date date,
        delete_date date,
        email varchar(255),
        mobile varchar(255),
        name varchar(255),
        password varchar(255),
        primary key (admin)
    )
Hibernate: 
    create table cart (
        cart_id integer not null auto_increment,
        create_date date,
        delete_date date,
        primary key (cart_id)
    )
Hibernate: 
    create table cart_product (
        cart_cart_id integer not null,
        products_product_id integer not null,
        primary key (cart_cart_id, products_product_id)
    )
Hibernate: 
    create table category (
        category_id integer not null auto_increment,
        category_name varchar(255),
        create_date date,
        delete_date date,
        primary key (category_id)
    )
Hibernate: 
    create table customer (
        customer_id integer not null auto_increment,
        DOB date,
        create_date date,
        delete_date date,
        email varchar(255),
        mobile varchar(255),
        name varchar(255),
        password varchar(255),
        cart_id integer,
        wishlist_id integer,
        primary key (customer_id)
    )
Hibernate: 
    create table customer_address (
        customer_customer_id integer not null,
        addresses_address_id integer not null,
        primary key (customer_customer_id, addresses_address_id)
    )
Hibernate: 
    create table customer_order (
        customer_id integer not null,
        order_id integer not null,
        primary key (customer_id, order_id)
    )
Hibernate: 
    create table image (
        image_id integer not null auto_increment,
        imageURL varchar(255),
        primary key (image_id)
    )
Hibernate: 
    create table merchant (
        merchant_id integer not null auto_increment,
        create_date date,
        delete_date date,
        email varchar(255),
        mobile varchar(255),
        name varchar(255),
        password varchar(255),
        primary key (merchant_id)
    )
Hibernate: 
    create table merchant_product (
        merchant_merchant_id integer not null,
        products_product_id integer not null,
        primary key (merchant_merchant_id, products_product_id)
    )
Hibernate: 
    create table orderings (
        orderings_id integer not null auto_increment,
        create_date date,
        delete_date date,
        delevery_date date,
        order_date date,
        status varchar(255),
        primary key (orderings_id)
    )
Hibernate: 
    create table orderings_product (
        orderings_orderings_id integer not null,
        products_product_id integer not null,
        primary key (orderings_orderings_id, products_product_id)
    )
Hibernate: 
    create table product (
        product_id integer not null auto_increment,
        cost double precision not null,
        create_date date,
        delete_date date,
        description varchar(255),
        discount double precision not null,
        name varchar(255),
        quantity integer not null,
        rating integer not null,
        primary key (product_id)
    )
Hibernate: 
    create table product_category (
        product_id integer not null,
        category_id integer not null,
        primary key (product_id, category_id)
    )
Hibernate: 
    create table product_image (
        product_product_id integer not null,
        images_image_id integer not null,
        primary key (product_product_id, images_image_id)
    )
Hibernate: 
    create table product_review (
        product_product_id integer not null,
        reviews_review_id integer not null,
        primary key (product_product_id, reviews_review_id)
    )
Hibernate: 
    create table review (
        review_id integer not null auto_increment,
        create_date date,
        delete_date date,
        review varchar(255),
        primary key (review_id)
    )
Hibernate: 
    create table wishlist (
        wishlist_id integer not null auto_increment,
        create_date date,
        delete_date date,
        primary key (wishlist_id)
    )
Hibernate: 
    create table wishlist_product (
        wishlist_wishlist_id integer not null,
        products_product_id integer not null,
        primary key (wishlist_wishlist_id, products_product_id)
    )
Hibernate: 
    alter table cart_product 
        add constraint UK_gox1cqiv8w5xlllt94n5v2cw5  unique (products_product_id)
Hibernate: 
    alter table customer_address 
        add constraint UK_jcyvwl9wa94nrxi16uo83hr7o  unique (addresses_address_id)
Hibernate: 
    alter table merchant_product 
        add constraint UK_g4h0dv18ew3au17ys9m7umpkc  unique (products_product_id)
Hibernate: 
    alter table orderings_product 
        add constraint UK_onp5kpln9vi79qtirhcxlidcj  unique (products_product_id)
Hibernate: 
    alter table product_image 
        add constraint UK_e0ep9h3eell6v5ejymkstylck  unique (images_image_id)
Hibernate: 
    alter table product_review 
        add constraint UK_84i3bc06o3iieeacgolb7g5jw  unique (reviews_review_id)
Hibernate: 
    alter table wishlist_product 
        add constraint UK_3feat79jpxmy1ni9i5e31ic  unique (products_product_id)
Hibernate: 
    alter table cart_product 
        add constraint FK_gox1cqiv8w5xlllt94n5v2cw5 
        foreign key (products_product_id) 
        references product (product_id)
Hibernate: 
    alter table cart_product 
        add constraint FK_mudxkokace5pu660xa8ihskrs 
        foreign key (cart_cart_id) 
        references cart (cart_id)
Hibernate: 
    alter table customer 
        add constraint FK_g9sk3sbpw80xw32a5b435qvw2 
        foreign key (cart_id) 
        references cart (cart_id)
Hibernate: 
    alter table customer 
        add constraint FK_q5u25xon0428460a52gknpa1h 
        foreign key (wishlist_id) 
        references wishlist (wishlist_id)
Hibernate: 
    alter table customer_address 
        add constraint FK_jcyvwl9wa94nrxi16uo83hr7o 
        foreign key (addresses_address_id) 
        references address (address_id)
Hibernate: 
    alter table customer_address 
        add constraint FK_dvhmch9fuobb5djmjsrdot7ej 
        foreign key (customer_customer_id) 
        references customer (customer_id)
Hibernate: 
    alter table customer_order 
        add constraint FK_4mvuet70060blqipb0e5l7ghy 
        foreign key (order_id) 
        references orderings (orderings_id)
Hibernate: 
    alter table customer_order 
        add constraint FK_puwshb8ptuseofvg0vd8iktd5 
        foreign key (customer_id) 
        references customer (customer_id)
Hibernate: 
    alter table merchant_product 
        add constraint FK_g4h0dv18ew3au17ys9m7umpkc 
        foreign key (products_product_id) 
        references product (product_id)
Hibernate: 
    alter table merchant_product 
        add constraint FK_r9f6gx81k1qomr7e31xysi03p 
        foreign key (merchant_merchant_id) 
        references merchant (merchant_id)
Hibernate: 
    alter table orderings_product 
        add constraint FK_onp5kpln9vi79qtirhcxlidcj 
        foreign key (products_product_id) 
        references product (product_id)
Hibernate: 
    alter table orderings_product 
        add constraint FK_te0qvk1b0ophfen71p64rkgr4 
        foreign key (orderings_orderings_id) 
        references orderings (orderings_id)
Hibernate: 
    alter table product_category 
        add constraint FK_ac25kv0aljr3ts4lux00s93yt 
        foreign key (category_id) 
        references category (category_id)
Hibernate: 
    alter table product_category 
        add constraint FK_cm5vajyq5tshew4w6xvutslrw 
        foreign key (product_id) 
        references product (product_id)
Hibernate: 
    alter table product_image 
        add constraint FK_e0ep9h3eell6v5ejymkstylck 
        foreign key (images_image_id) 
        references image (image_id)
Hibernate: 
    alter table product_image 
        add constraint FK_blukjd3al93pbira72nwbfpcq 
        foreign key (product_product_id) 
        references product (product_id)
Hibernate: 
    alter table product_review 
        add constraint FK_84i3bc06o3iieeacgolb7g5jw 
        foreign key (reviews_review_id) 
        references review (review_id)
Hibernate: 
    alter table product_review 
        add constraint FK_29oj6i5rt1tlaqx7ma6d4w3a8 
        foreign key (product_product_id) 
        references product (product_id)
Hibernate: 
    alter table wishlist_product 
        add constraint FK_3feat79jpxmy1ni9i5e31ic 
        foreign key (products_product_id) 
        references product (product_id)
Hibernate: 
    alter table wishlist_product 
        add constraint FK_mex7b175299ysr35h6djkd48n 
        foreign key (wishlist_wishlist_id) 
        references wishlist (wishlist_id)