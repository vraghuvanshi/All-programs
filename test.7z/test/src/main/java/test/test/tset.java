package test.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class tset {

	public static void main(String[] args) {
		
	}
	
	
	public EntityManager sens(){
		
		EntityManagerFactory emFactory= Persistence.createEntityManagerFactory("hello");
		EntityManager em=emFactory.createEntityManager();
		return em;
	}

}
