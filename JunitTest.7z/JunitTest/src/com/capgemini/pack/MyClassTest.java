package com.capgemini.pack;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;


import com.capgemini.junit.*;
public class MyClassTest {
  

  @Test
  public void fiveFactorialIsOneTwenty() {
	 MyTest tester=new MyTest();
	 assertEquals(120, tester.factorial(5));  
    
  }
  
  @Test
  public void zeroFactorialIsOne() {
	 MyTest tester=new MyTest();
	 assertEquals(1, tester.factorial(0));  
    
  }
  
  @Test
  public void oneFactorialIsOne() {
	 MyTest tester=new MyTest();
	 assertEquals(1, tester.factorial(0));  
    
  }
  
  @Test
  public void sevenIsArmstrongNumber() {
	 MyTest tester=new MyTest();
	assertTrue(tester.armstrongNumber(7));  
    
  }
  
  @Test
  public void oneFiftyThreeIsArmstrongNumber() {
	 MyTest tester=new MyTest();
	
	assertTrue(tester.armstrongNumber(153));  
    
  }
  
  @Test
  public void sixtenThirtyFourIsArmstrongNumber() {
	 MyTest tester=new MyTest();
	assertTrue(tester.armstrongNumber(1634));;  
    
  }
  
  @Test(expected =IllegalArgumentException.class)
  public void negativeNumberAreNotArmstrongNumber() {
	 MyTest tester=new MyTest();
	 tester.armstrongNumber(-45);  
    
  }
  
} 
 