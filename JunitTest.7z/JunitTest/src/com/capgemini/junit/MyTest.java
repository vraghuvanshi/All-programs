package com.capgemini.junit;



public class MyTest {
	
	public long factorial(int num){
		if(num==0|| num==1){
			return 1;
			
		}
		
		else{
			int fact=1;
			while(num!=0){
				fact=fact*num;
				num--;
			}
			return fact;
		}
	}
	
	public boolean armstrongNumber(int num){
		if(num<0){
			throw new IllegalArgumentException();
		}
		
		else{
			
			Integer integer=num;
			String str=integer.toString();
			int counter=str.length();
			
			int mod,sum=0,temporary=num;
			while(temporary!=0){
				mod=temporary%10;
				sum=(int) (sum+Math.pow(mod,counter));
				temporary=temporary/10;
			}
			if(num==sum){
			
				return true;
			}
		}
		return false;
		
	}
		
	
	
	
	

}
