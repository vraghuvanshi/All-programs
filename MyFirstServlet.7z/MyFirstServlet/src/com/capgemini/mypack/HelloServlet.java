package com.capgemini.mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public HelloServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	System.out.println("Hello Console");
	PrintWriter printWriter=response.getWriter();
	
	printWriter.print("Hello");
	printWriter.println("<br>");
	printWriter.println("Servlet");
	
	int number1=Integer.parseInt(request.getParameter("number1"));
	int number2=Integer.parseInt(request.getParameter("number2"));
	
	String choice=request.getParameter("operation");
	int result = 0;
	switch(choice){
	case "Add": result= number1+number2;
				break;
				
	case "Subtract": result= number1-number2;
					  break;
	
	case "Multiply": result= number1*number2;
					  break;
	
	case "Divide": result= number1/number2;
					break;
				
	
	}
	
	printWriter.println("<br>");
	printWriter.println("Result of opeartion "+result);
	printWriter.println("<br>");
	Enumeration<String> parameternames=request.getParameterNames();
	
	

	while (parameternames.hasMoreElements()){
			printWriter.println(parameternames.nextElement());
			printWriter.println("<br>");
	}
	
	Enumeration<String>  headerName=request.getHeaderNames();
	
	
	while(headerName.hasMoreElements()){
		printWriter.println(headerName.nextElement());
		printWriter.println("<br>");
	}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
