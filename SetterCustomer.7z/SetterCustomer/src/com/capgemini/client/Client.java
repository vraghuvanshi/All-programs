package com.capgemini.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.service.Service;

public class Client {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Service service=(Service) context.getBean("service");
		
		System.out.println(service.findAll().get(0).getFirstName());
	}

}

