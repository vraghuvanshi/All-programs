package com.capgemini.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ThirdServlet")
public class ThirdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ThirdServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String firstName=(String) session.getAttribute("firstName");
		String lastName=(String) session.getAttribute("lastName");
		
		String qualification=request.getParameter("qualification");
		
		session.setAttribute("qualification", qualification);
		out.print("First Name"+firstName);
		out.println("<br>");
		out.println("Last Name "+lastName);
		out.println("<br>");
		out.println("Qualification "+qualification);
		out.println("<br>");
		
		out.println("<html>");
		out.println("<body>");
		out.println("<form action=FourthServlet >");
		out.println("Marks :<input type=text name=marks placeholder=marks>");
		out.println("<input type=submit value=submit");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	
	}

}
