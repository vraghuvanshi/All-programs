package com.capgemini.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SecondServlet() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String firstName=(String) session.getAttribute("firstName");
		
		String lastName=request.getParameter("lastName");
		
		session.setAttribute("lastName", lastName);
		out.print("First Name "+firstName);
		out.println("<br>");
		out.println("Last Name "+lastName);
		out.println("<br>");
		
		out.println("<html>");
		out.println("<body>");
		out.println("<form action=ThirdServlet >");
		out.println("Qualification :<input type=text name=qualification placeholder=Qualification>");
		out.println("<input type=submit value=submit");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
