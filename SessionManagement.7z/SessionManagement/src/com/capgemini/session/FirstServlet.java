package com.capgemini.session;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet  {
	private static final long serialVersionUID = 1L;
       
   
    public FirstServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		String firstName=request.getParameter("firstName");
		
		
		
		HttpSession session=request.getSession();
		session.setAttribute("firstName", firstName);
		
		out.println("First Name "+firstName);
		out.println("<br>");
		out.println("<html>");
		out.println("<body>");
		out.println("<form action=SecondServlet >");
		out.println("Last Name :<input type=text name=lastName placeholder=LastName>");
		out.println("<input type=submit value=submit");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
		
		
		
		
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
