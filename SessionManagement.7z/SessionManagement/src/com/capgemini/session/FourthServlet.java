package com.capgemini.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/FourthServlet")
public class FourthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public FourthServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String firstName=(String) session.getAttribute("firstName");
		String lastName=(String) session.getAttribute("lastName");
		
		String qualification=(String) session.getAttribute("qualification");
		String marks=request.getParameter("marks");
		
		session.setAttribute("marks", marks);
		out.println("<br>");
		out.print("First Name "+firstName);
		out.println("<br>");
		out.println("Last Name "+lastName);
		out.println("<br>");
		out.println("Qualification "+qualification);
		out.println("<br>");
		out.println("Marks "+marks);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
