package com.capgemini.repo;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.modal.Customer;



public class Repository {
	
	List<Customer> customers=new ArrayList<>();
	/*static int count;
	public String addCustomer(Customer customer){
		if (customer!=null)
		{
			customers.add(count, customer);
			return "success";
		}
		else 
			return "fail";
		
	}
	*/
	public List<Customer> findAll(){
		
		Customer customer=new Customer();
	
		customer.setFirstName("Vinay");
		customer.setLastName("Raghuvanshi");
		customers.add(0, customer);
		
		return customers;
	}

}
