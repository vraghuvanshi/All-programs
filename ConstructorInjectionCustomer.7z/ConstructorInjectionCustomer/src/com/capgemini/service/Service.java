package com.capgemini.service;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.modal.Customer;
import com.capgemini.repo.Repository;

public class Service {
	
	
	//private Customer customer;
	private Repository repo=new Repository();
	/*
	public String addCustomer(String firstName, String lastName){
		ApplicationContext context=new ClassPathXmlApplicationContext("First.xml");
		Customer customer=(Customer) context.getBean("customer");
		String result=repo.addCustomer(customer);
		return result;

	}
	*/
	
	
	
	public List<Customer> findAll(){
		List<Customer> customers;
		customers=repo.findAll();
		
		return customers;
		
	}



	public Repository getRepo() {
		return repo;
	}



	public void setRepo(Repository repo) {
		this.repo = repo;
	}
	
	

}
