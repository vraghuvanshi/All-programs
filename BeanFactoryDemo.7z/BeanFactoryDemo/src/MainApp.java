
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;


public class MainApp {

	public static void main(String[] args) {
		/*BeanFactory beanFactory=(BeanFactory) new XmlBeanFactory(new ClassPathResource("NewFile.xml"));
		System.out.println("Inside main");
		Employee emp=(Employee) beanFactory.getBean("emp");
		System.out.println(emp.getId()+" "+emp.getName());*/
		
		
		
		Resource resource=   new FileSystemResource("Spring.xml");
		//org.springframework.core.io.Resource resource = new FileSystemResource("Spring.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Employee emp=(Employee) factory.getBean("emp");
		System.out.println(emp.getId()+" "+emp.getName());
	}

}
