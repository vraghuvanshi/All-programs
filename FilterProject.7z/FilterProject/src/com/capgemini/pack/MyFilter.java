package com.capgemini.pack;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebFilter
public class MyFilter implements Filter {

    public MyFilter() {
      
    }

	
	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request2=(HttpServletRequest) request;
		HttpServletResponse response2=(HttpServletResponse) response;
		
		String userAgent=request2.getHeader("user-agent");
		//System.out.println(userAgent);
		String language=request2.getHeader("accept-language");
		//System.out.println(userAgent);
		//System.out.println(language);
		
		request2.setAttribute("name", "Vinay");
		request2.setAttribute("userAgent", userAgent);
		request2.setAttribute("language", language);
		chain.doFilter(request2, response2);
	
		
	}
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
