package com.fms.pojo;

import java.util.Date;
import java.util.List;


import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToMany;

import javax.persistence.OneToOne;

@Entity
public class Film {
	
	@Id @GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
	private String title;
	private String descriptor;
	private Date releaseDate;
	
	@OneToOne
	private Album album;
	



	private String language;
	@ManyToMany
	private List<Actor> actor;
	@ManyToMany
	private List<Category> category;
	
	private byte rating;
	private Date deleteDate;
	private short length;
	private Date createDate;
	
	
	public Film(int id, String title, String descriptor, Date releaseDate, String language, List<Actor> actor,
			List<Category> category, byte rating, Date deleteDate, short length, Date createDate) {
		super();
		this.id = id;
		this.title = title;
		this.descriptor = descriptor;
		this.releaseDate = releaseDate;
		this.language = language;
		this.actor = actor;
		this.category = category;
		this.rating = rating;
		this.deleteDate = deleteDate;
		this.length = length;
		this.createDate = createDate;
	}


	public Film() {
		super();
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescriptor() {
		return descriptor;
	}


	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}


	public Date getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}


	public String getLanguage() {
		return language;
	}


	public void setLanguage(String language) {
		this.language = language;
	}


	public List<Actor> getActor() {
		return actor;
	}


	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}


	public List<Category> getCategory() {
		return category;
	}


	public void setCategory(List<Category> category) {
		this.category = category;
	}


	public byte getRating() {
		return rating;
	}


	public void setRating(byte rating) {
		this.rating = rating;
	}


	public Date getDeleteDate() {
		return deleteDate;
	}


	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}


	public short getLength() {
		return length;
	}


	public void setLength(short length) {
		this.length = length;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	public Album getAlbum() {
		return album;
	}


	public void setAlbum(Album album) {
		this.album = album;
	}


	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", descriptor=" + descriptor + ", releaseDate=" + releaseDate
				+ ", album=" + album + ", language=" + language + ", actor=" + actor + ", category=" + category
				+ ", rating=" + rating + ", deleteDate=" + deleteDate + ", length=" + length + ", createDate="
				+ createDate + "]";
	}


	
	
	
	

}
