package com.fms.Doa;

import java.util.List;

import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

public interface IFilmDoa {
	public String save(Film film);
	public String modifyFilm(Film film);
	public String deleteFilm(String title);
	public List<Film> searchFilmByTitle(String title);
	public List<Film> searchFilmByCategory(Category category);
	public List<Film> searchFilmByRating(byte rating);
	public List<Film> searchFilmByLanguage(String language);
	public List<Film> searchFilmByActor(Actor actor);

}
