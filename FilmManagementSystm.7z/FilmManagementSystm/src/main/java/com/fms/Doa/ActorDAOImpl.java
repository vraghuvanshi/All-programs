package com.fms.Doa;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Image;

public class ActorDAOImpl implements IActorDoa {

	private EntityManager em;

	public ActorDAOImpl(EntityManager em) {
		this.em = em;
	}

	public String save(Actor actor) {
		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor.getFirstName()).getSingleResult();

			if (ac == null) {
				em.persist(actor);
				return "success";
			} else
				return "fail";
		} catch (NoResultException e) {
			em.persist(actor);
			return "success";
		}
	}

	public List<Actor> searchActorByName(String firstName, String lastName) {

		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
				Actor.class);
		List<Actor> list = query.setParameter("f", firstName).setParameter("l", lastName).getResultList();
		return list;

	}

	public List<Actor> searchByAge(byte age) {

		return null;
	}

	public String modifyActor(Actor actor) {

		Actor savedActor = em.find(Actor.class, actor.getId());
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		savedActor.setFilm(actor.getFilm());
		em.persist(actor);
		return "success";
	}

	public String removeActor(Actor actor) {
		try {
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
					Actor.class);
			Actor actor1 = query.setParameter("f", actor.getFirstName()).setParameter("l", actor.getLastName()).getSingleResult();
			actor1.setDeleteDate(new Date());
			em.persist(actor1);
			return "success";
		} catch (Exception e) {
			return "fail";
		}
	}

	public List<Actor> getActors() {

		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a", Actor.class);
			List<Actor> ac = query.getResultList();

			return ac;
		} catch (NoResultException e) {
			return null;
		}

	}

	public Album addAlbum(Album album) {

		em.persist(album);
		System.out.println("album save");
		return album;
	}

	public Image addImage(Image img) {

		try {

			em.persist(img);
			return img;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	



}
