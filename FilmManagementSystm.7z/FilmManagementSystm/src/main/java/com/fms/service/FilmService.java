package com.fms.service;

import java.util.List;


import com.fms.Doa.IFilmDoa;
import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

public class FilmService implements IFilmService {
	
	IFilmDoa filmRepository;
	
	

	public FilmService(IFilmDoa filmRepository) {
		super();
		this.filmRepository = filmRepository;
	}

	
	
	public String addFilm(Film film) {
		if(film==null){
			throw new IllegalArgumentException();
		}
		else{
				try{
			
					String result=filmRepository.save(film);
					return result;
				}
				catch(Exception e){
					return e.getMessage();
				}
		}
	}

	public String modifyFilm(Film film) {
		if(film==null){
			throw new IllegalArgumentException();
		}
		else{
			try{
			
				String str=filmRepository.modifyFilm(film);
				return str;
			}
			catch(Exception e){
				return e.getMessage();
			}
		}
	}

	public String deleteFilm(String title) {
		if(title==null){
			throw new IllegalArgumentException();
		}
		else{
			try{
			
				String result=filmRepository.deleteFilm(title);
				return result;
			}
			catch(Exception e){
				return e.getMessage();
			}
		}
	}

	public List<Film> searchFilmBytitle(String title) {
		if(title==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film = null;
			try{
				 film=filmRepository.searchFilmByTitle(title);
				return film;
			}
			catch(Exception e){
				return film;
			}
		}
		
	}

	public List<Film> searchFilmByCategory(Category category) {
		if(category==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film = null;
			try{
				film = filmRepository.searchFilmByCategory(category);
				return film;
			}
			catch(Exception e){
				return film;
			}
		}
	}

	public List<Film> searchFilmByRating(byte rating) {
		if (rating==0){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film = null;
			try{
				film = filmRepository.searchFilmByRating(rating);
				return film;
			}
			catch(Exception e){
				return film;
			}
		
		}
		
	}

	public List<Film> searchFilmByLanguage(String language) {
		
		if(language==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film = null;
			try{
			film =filmRepository.searchFilmByLanguage(language);
				return film;
			}
			catch(Exception e){
				return film;
			}
		}
	}

	public List<Film> searchFilmByActor(Actor actor) {
		if(actor==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film = null;
			try{
				 film=filmRepository.searchFilmByActor(actor);
				return film;
			}
			catch(Exception e){
				return film;
			}
		}
	}
	

}
