package com.capgemini.service;
import java.util.List;

import com.capgemini.modal.Customer;
import com.capgemini.repo.Repository;

public class Service {
	
	
	private Customer customer;
	private Repository repo=new Repository();
	
	public String addCustomer(String firstName, String lastName){
		customer=new Customer(firstName,lastName);
		String result=repo.addCustomer(customer);
		return result;

	}
	
	public List<Customer> findAll(){
		List<Customer> customers;
		customers=repo.findAll();
		
		return customers;
		
	}
	
	

}
