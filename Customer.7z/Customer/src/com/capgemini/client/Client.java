package com.capgemini.client;

import com.capgemini.service.Service;

public class Client {

	public static void main(String[] args) {
		
		Service service=new Service();
		
		String result=service.addCustomer("Vinay", "Raghuvanshi");
		System.out.println(result);
		result=service.addCustomer("Anand", "Kumar");
		System.out.println(result);
		
		System.out.println(service.findAll().get(0).getFirstName());

	}

}
