package com.capgemini.pack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class MyListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		ServletContext sc=event.getServletContext();
		String driver=sc.getInitParameter("Driver");
		String url=sc.getInitParameter("Url");
		String userId=sc.getInitParameter("UserId");
		String password=sc.getInitParameter("Password");
		
		try {
			Class.forName(driver);
			System.out.println("Driver loaded");
			Connection con=DriverManager.getConnection(url,userId,password);
			System.out.println("Connection Establish");
			sc.setAttribute("Connection",con);
			
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			System.out.println(e.getMessage());
		}
		
	}

    
	
}
