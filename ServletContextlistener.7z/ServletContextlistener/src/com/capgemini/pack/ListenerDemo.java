package com.capgemini.pack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/ListenerDemo")
public class ListenerDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ListenerDemo() {
        super();
      
    }
    
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=(Connection) getServletContext().getAttribute("Connection");
	try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select name from employee where id=1");
		rs.next();
		
		PrintWriter pw=response.getWriter();
		pw.println(rs.getString(1));
		
		System.out.println(rs.getString(1));
	}
	catch (SQLException e) {
		
		e.printStackTrace();
	}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
