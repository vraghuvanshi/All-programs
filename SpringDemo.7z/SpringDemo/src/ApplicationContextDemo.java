import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationContextDemo {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("First.xml");
		System.out.println("Inside main");
		Employee emp=(Employee) context.getBean("emp");
		System.out.println(emp.getId()+" "+emp.getName());
		
		
		Employee emp1=(Employee) context.getBean("emp1");
		System.out.println(emp1.getId()+" "+emp1.getName());

		
		
		Employee emp2=(Employee) context.getBean("emp2");
		System.out.println(emp2.getId()+" "+emp2.getName());
		
		Employee emp3=(Employee) context.getBean("emp3");
		System.out.println(emp3.getId()+" "+emp3.getName());
		
	}

}
